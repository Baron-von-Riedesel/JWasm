
  Regression Tests for JWasm

  1. Prepare Tests
  
  - tool JFC must be created. Source code is supplied in the Samples
  directory.
  - jwlink (modified OW WLink) must be downloaded from japheth.de.
  - MS link from VC 8 is used for one Win64 SEH test. If it is not
    available, this test must be commented out in runtest.cmd.
    (to be improved)
  - all tools must be copied to directory ..\Tools

  2. Run Tests
  
  Windows: RUNTEST.CMD
  Linux:   (todo)

  If everything is ok, there's no display at all.

