#!/bin/sh
zip -R Regression *.ASM *.EXP *.INC *.lib *.BAT *.CMD *.txt *.sh
