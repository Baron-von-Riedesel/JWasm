
/* compile: cl -Zp4 struct02.c */

#include <stdio.h>
#include <stdlib.h>

typedef struct _s01 {
    short v1;
    short v2;
    short v3;
} s01;

typedef struct _s02 {
    long  v1;
    short v2;
} s02;

typedef struct _s03 {
    short v1;
    long  v2;
} s03;

typedef struct _s04 {
    short v1;
    s03 v2;
} s04;

#pragma pack(push,8)
typedef struct _s05 {
	short v1;
    s03 v2;
} s05;
#pragma pack(pop)

typedef struct _s06 {
	__int64 v1;
    short v2;
} s06;

typedef struct _s07 {
	short v1;
    s06 v2;
} s07;

typedef struct _s08 {
	short v1;
    s01 v2;
} s08;

typedef struct _s11 {
	short v1;
	struct {
		short v2;
	};
} s11;

typedef struct _s12 {
	short v1;
	struct {
		long v2;
	};
} s12;

typedef struct _s13 {
	short v1;
	struct {
		short v2;
		long v3;
	};
} s13;

typedef struct _s14 {
	short v1;
	struct {
		char v2;
		long v3;
	};
} s14;

typedef struct _s21 {
	struct {
		char v1;
	};
	struct {
		short v2;
	};
	struct {
		long v3;
	};
} s21;

typedef struct _s31 {
	char v1[3];
	struct {
		short v2;
	};
	struct {
		char v3[3];
	};
} s31;

typedef struct _s41 {
	char v1;
	struct {
		char rf1:1;
		char rf2:3;
		char rf3:2;
	} v2;
} s41;

typedef struct _s42 {
	char v1;
	struct {
		char rf1:1;
		char rf2:3;
		char rf3:2;
	} v2;
	long v3;
} s42;

s01 v01;
s02 v02;
s03 v03;
s04 v04;
s05 v05;
s06 v06;
s07 v07;
s08 v08;
s11 v11;
s12 v12;
s13 v13;
s14 v14;
s21 v21;
s31 v31;
s41 v41;
s42 v42;

int main()
{
	printf("sizeof s01=%u s02=%u s03=%u s04=%u s05=%u s06=%u s07=%u s08=%u\n",
		   sizeof(s01), sizeof(s02), sizeof(s03), sizeof(s04), sizeof(s05), sizeof(s06), sizeof(s07), sizeof(s08) );
	printf("sizeof s11=%u s12=%u s13=%u s14=%u\n",
		   sizeof(s11), sizeof(s12), sizeof(s13), sizeof(s14) );
	printf("sizeof s21=%u\n",
		   sizeof(s21) );
	printf("sizeof s31=%u\n",
		   sizeof(s31) );
	printf("sizeof s41=%u s42=%u\n",
		   sizeof(s41), sizeof(s42) );
    return( 0 );
}
